<?php
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=10.1.88.8;port=3306;dbname=tcds',
    'username' => 'tcds',
    'password' => 'tcds',
    'charset' => 'utf8',
];
