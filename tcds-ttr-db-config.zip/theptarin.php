<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=10.1.99.19;port=3306;dbname=theptarin',
    'username' => 'tcds',
    'password' => 'tcds',
    'charset' => 'utf8',

    // Schema cache options (for production environment)
    //'enableSchemaCache' => true,
    //'schemaCacheDuration' => 60,
    //'schemaCache' => 'cache',
];
